# Keputusan Teknis & Log Progress

> File ini adalah "kartu status" proyek. **Selalu upload file ini bersama folder proyek** saat melanjutkan pekerjaan di sesi/akun Claude yang berbeda, supaya konteks tidak hilang.

---

## Cara Pakai File Ini

1. Setiap kali sebuah keputusan teknis dibuat (lihat daftar pertanyaan terbuka di bawah), catat jawabannya di Bagian 1.
2. Setiap kali sebuah checklist fase di `docs/PLAN-SIMRS-KHANZA-WEB-KEBIDANAN.md` selesai, update juga ringkasan progress di Bagian 2 file ini.
3. Saat mulai sesi baru: upload folder project ini (terutama `docs/`) lalu katakan ke Claude, contoh:
   > "Lanjutkan proyek SIMRS Khanza Web Kebidanan. Baca docs/PLAN-SIMRS-KHANZA-WEB-KEBIDANAN.md dan docs/KEPUTUSAN-TEKNIS.md, kita baru selesai Fase 1."

---

## 1. Keputusan Teknis (Jawaban dari Bagian 8 Dokumen Rencana)

| # | Pertanyaan | Status | Jawaban / Keputusan |
|---|---|---|---|
| 1 | Format & generator `no_rawat` dan `no_rkm_medis` | ⏳ Belum dikonfirmasi | — |
| 2 | Algoritma hash password tabel `user` | ⏳ Belum dikonfirmasi | — |
| 3 | Kode poli & kode dokter khusus kebidanan/kecantikan di RSU Al-Arif | ⏳ Belum dikonfirmasi | — |
| 4 | Versi PHP & ekstensi server (mysqli/PDO, GD/Imagick) | ⏳ Belum dikonfirmasi | — |
| 5 | Kebijakan validasi resep (berbasis tanggal vs SOP khusus) | ⏳ Belum dikonfirmasi | — |
| 6 | Opsi A vs B untuk modul kecantikan (tabel baru vs field generik) | ⏳ Belum dikonfirmasi | — |

> Update tabel di atas begitu Anda punya jawabannya (boleh dari cek source Java, atau dari SOP RSU Al-Arif).

---

## 2. Ringkasan Progress per Fase

| Fase | Status | Tanggal Selesai | Catatan |
|---|---|---|---|
| Fase 0 — Persiapan & Validasi Lingkungan | 🟡 Sedang berjalan | — | Struktur folder, git init, config koneksi, tema CSS sudah dibuat. Menunggu uji koneksi ke DB server asli. |
| Fase 1 — Login, Layout, Generator no_rawat | ⬜ Belum mulai | — | |
| Fase 2 — Registrasi Pasien | ⬜ Belum mulai | — | |
| Fase 3 — Asesmen & SOAP | ⬜ Belum mulai | — | |
| Fase 4 — USG, Tindakan, Resep | ⬜ Belum mulai | — | |
| Fase 5 — Billing & Pembukuan | ⬜ Belum mulai | — | |
| Fase 6 — Modul Kecantikan | ⬜ Belum mulai (perlu keputusan #6) | — | |
| Fase 7 — Hardening & Deployment | ⬜ Belum mulai | — | |

Legenda: ⬜ belum mulai · 🟡 sedang berjalan · ✅ selesai · 🔴 terhambat (butuh keputusan)

---

## 3. File Penting yang Sudah Dibuat (Fase 0)

```
simrs-kebidanan/
├── config/
│   ├── koneksi.php       → Koneksi PDO ke database `sik` (prepared statement wajib)
│   └── app.php           → Konstanta aplikasi (role, status enum, dll — tanpa secret)
├── assets/css/theme.css  → Tema warna merah maroon profesional (sesuai Bagian 3 rencana)
├── test-koneksi.php      → Halaman uji SELECT ke pasien/reg_periksa/poliklinik/dokter/user
├── preview-tema.html     → Preview visual komponen UI (sidebar, card, table, badge, form)
└── docs/
    ├── PLAN-SIMRS-KHANZA-WEB-KEBIDANAN.md   → Dokumen rencana utama (jangan dihapus/diringkas)
    └── KEPUTUSAN-TEKNIS.md                   → File ini
```

---

## 4. Langkah Selanjutnya (Next Action)

- [ ] Jalankan `test-koneksi.php` di server yang sudah diisi kredensial DB asli (edit `config/koneksi.php`).
- [ ] Cek `preview-tema.html` di browser, konfirmasi skema warna sudah sesuai selera (boleh request revisi warna di sini sebelum lanjut Fase 1).
- [ ] Jika perlu, mulai jawab pertanyaan di Bagian 1 (terutama #1 dan #2 — ini blocker untuk Fase 1).
- [ ] Setelah itu, lanjut ke **Fase 1: Login, Layout, & Generator `no_rawat`**.
